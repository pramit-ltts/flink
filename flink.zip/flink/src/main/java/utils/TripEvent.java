package utils;



import org.apache.avro.message.BinaryMessageDecoder;
import org.apache.avro.message.BinaryMessageEncoder;
import org.apache.avro.message.SchemaStore;
import org.apache.avro.specific.SpecificData;

@SuppressWarnings("all")
@org.apache.avro.specific.AvroGenerated
public class TripEvent extends org.apache.avro.specific.SpecificRecordBase implements org.apache.avro.specific.SpecificRecord {
  private static final long serialVersionUID = 7339472091887058343L;
  public static final org.apache.avro.Schema SCHEMA$ = new org.apache.avro.Schema.Parser().parse("{\"type\":\"record\",\"name\":\"TripEvent\",\"namespace\":\"com.amazonaws.samples.kaja.streaming.etl.events\",\"fields\":[{\"name\":\"vendor_id\",\"type\":\"int\"},{\"name\":\"pickup_datetime\",\"type\":{\"type\":\"long\",\"logicalType\":\"timestamp-millis\"}},{\"name\":\"dropoff_datetime\",\"type\":{\"type\":\"long\",\"logicalType\":\"timestamp-millis\"}},{\"name\":\"passenger_count\",\"type\":\"int\"},{\"name\":\"trip_distance\",\"type\":\"double\"},{\"name\":\"ratecode_id\",\"type\":\"int\"},{\"name\":\"store_and_fwd_flag\",\"type\":\"string\"},{\"name\":\"pickup_location_id\",\"type\":\"int\"},{\"name\":\"dropoff_location_id\",\"type\":\"int\"},{\"name\":\"payment_type\",\"type\":\"int\"},{\"name\":\"fare_amount\",\"type\":\"double\"},{\"name\":\"extra\",\"type\":\"double\"},{\"name\":\"mta_tax\",\"type\":\"double\"},{\"name\":\"tip_amount\",\"type\":\"double\"},{\"name\":\"tolls_amount\",\"type\":\"double\"},{\"name\":\"improvement_surcharge\",\"type\":\"double\"},{\"name\":\"total_amount\",\"type\":\"double\"},{\"name\":\"trip_id\",\"type\":\"long\"},{\"name\":\"type\",\"type\":\"string\"},{\"name\":\"padding\",\"type\":\"string\"}]}");
  public static org.apache.avro.Schema getClassSchema() { return SCHEMA$; }

  private static SpecificData MODEL$ = new SpecificData();

  private static final BinaryMessageEncoder<TripEvent> ENCODER =
      new BinaryMessageEncoder<TripEvent>(MODEL$, SCHEMA$);

  private static final BinaryMessageDecoder<TripEvent> DECODER =
      new BinaryMessageDecoder<TripEvent>(MODEL$, SCHEMA$);

  /**
   * Return the BinaryMessageDecoder instance used by this class.
   */
  public static BinaryMessageDecoder<TripEvent> getDecoder() {
    return DECODER;
  }

  /**
   * Create a new BinaryMessageDecoder instance for this class that uses the specified {@link SchemaStore}.
   * @param resolver a {@link SchemaStore} used to find schemas by fingerprint
   */
  public static BinaryMessageDecoder<TripEvent> createDecoder(SchemaStore resolver) {
    return new BinaryMessageDecoder<TripEvent>(MODEL$, SCHEMA$, resolver);
  }

  /** Serializes this TripEvent to a ByteBuffer. */
  public java.nio.ByteBuffer toByteBuffer() throws java.io.IOException {
    return ENCODER.encode(this);
  }

  /** Deserializes a TripEvent from a ByteBuffer. */
  public static TripEvent fromByteBuffer(
      java.nio.ByteBuffer b) throws java.io.IOException {
    return DECODER.decode(b);
  }

  @Deprecated public int vendor_id;
  @Deprecated public org.joda.time.DateTime pickup_datetime;
  @Deprecated public org.joda.time.DateTime dropoff_datetime;
  @Deprecated public int passenger_count;
  @Deprecated public double trip_distance;
  @Deprecated public int ratecode_id;
  @Deprecated public java.lang.CharSequence store_and_fwd_flag;
  @Deprecated public int pickup_location_id;
  @Deprecated public int dropoff_location_id;
  @Deprecated public int payment_type;
  @Deprecated public double fare_amount;
  @Deprecated public double extra;
  @Deprecated public double mta_tax;
  @Deprecated public double tip_amount;
  @Deprecated public double tolls_amount;
  @Deprecated public double improvement_surcharge;
  @Deprecated public double total_amount;
  @Deprecated public long trip_id;
  @Deprecated public java.lang.CharSequence type;
  @Deprecated public java.lang.CharSequence padding;

  /**
   * Default constructor.  Note that this does not initialize fields
   * to their default values from the schema.  If that is desired then
   * one should use <code>newBuilder()</code>.
   */
  public TripEvent() {}

  /**
   * All-args constructor.
   * @param vendor_id The new value for vendor_id
   * @param pickup_datetime The new value for pickup_datetime
   * @param dropoff_datetime The new value for dropoff_datetime
   * @param passenger_count The new value for passenger_count
   * @param trip_distance The new value for trip_distance
   * @param ratecode_id The new value for ratecode_id
   * @param store_and_fwd_flag The new value for store_and_fwd_flag
   * @param pickup_location_id The new value for pickup_location_id
   * @param dropoff_location_id The new value for dropoff_location_id
   * @param payment_type The new value for payment_type
   * @param fare_amount The new value for fare_amount
   * @param extra The new value for extra
   * @param mta_tax The new value for mta_tax
   * @param tip_amount The new value for tip_amount
   * @param tolls_amount The new value for tolls_amount
   * @param improvement_surcharge The new value for improvement_surcharge
   * @param total_amount The new value for total_amount
   * @param trip_id The new value for trip_id
   * @param type The new value for type
   * @param padding The new value for padding
   */
  public TripEvent(java.lang.Integer vendor_id, org.joda.time.DateTime pickup_datetime, org.joda.time.DateTime dropoff_datetime, java.lang.Integer passenger_count, java.lang.Double trip_distance, java.lang.Integer ratecode_id, java.lang.CharSequence store_and_fwd_flag, java.lang.Integer pickup_location_id, java.lang.Integer dropoff_location_id, java.lang.Integer payment_type, java.lang.Double fare_amount, java.lang.Double extra, java.lang.Double mta_tax, java.lang.Double tip_amount, java.lang.Double tolls_amount, java.lang.Double improvement_surcharge, java.lang.Double total_amount, java.lang.Long trip_id, java.lang.CharSequence type, java.lang.CharSequence padding) {
    this.vendor_id = vendor_id;
    this.pickup_datetime = pickup_datetime;
    this.dropoff_datetime = dropoff_datetime;
    this.passenger_count = passenger_count;
    this.trip_distance = trip_distance;
    this.ratecode_id = ratecode_id;
    this.store_and_fwd_flag = store_and_fwd_flag;
    this.pickup_location_id = pickup_location_id;
    this.dropoff_location_id = dropoff_location_id;
    this.payment_type = payment_type;
    this.fare_amount = fare_amount;
    this.extra = extra;
    this.mta_tax = mta_tax;
    this.tip_amount = tip_amount;
    this.tolls_amount = tolls_amount;
    this.improvement_surcharge = improvement_surcharge;
    this.total_amount = total_amount;
    this.trip_id = trip_id;
    this.type = type;
    this.padding = padding;
  }

  public org.apache.avro.Schema getSchema() { return SCHEMA$; }
  // Used by DatumWriter.  Applications should not call.
  public java.lang.Object get(int field$) {
    switch (field$) {
    case 0: return vendor_id;
    case 1: return pickup_datetime;
    case 2: return dropoff_datetime;
    case 3: return passenger_count;
    case 4: return trip_distance;
    case 5: return ratecode_id;
    case 6: return store_and_fwd_flag;
    case 7: return pickup_location_id;
    case 8: return dropoff_location_id;
    case 9: return payment_type;
    case 10: return fare_amount;
    case 11: return extra;
    case 12: return mta_tax;
    case 13: return tip_amount;
    case 14: return tolls_amount;
    case 15: return improvement_surcharge;
    case 16: return total_amount;
    case 17: return trip_id;
    case 18: return type;
    case 19: return padding;
    default: throw new org.apache.avro.AvroRuntimeException("Bad index");
    }
  }

  protected static final org.apache.avro.data.TimeConversions.DateConversion DATE_CONVERSION = new org.apache.avro.data.TimeConversions.DateConversion();
  protected static final org.apache.avro.data.TimeConversions.TimeConversion TIME_CONVERSION = new org.apache.avro.data.TimeConversions.TimeConversion();
  protected static final org.apache.avro.data.TimeConversions.TimestampConversion TIMESTAMP_CONVERSION = new org.apache.avro.data.TimeConversions.TimestampConversion();
  protected static final org.apache.avro.Conversions.DecimalConversion DECIMAL_CONVERSION = new org.apache.avro.Conversions.DecimalConversion();

  private static final org.apache.avro.Conversion<?>[] conversions =
      new org.apache.avro.Conversion<?>[] {
      null,
      TIMESTAMP_CONVERSION,
      TIMESTAMP_CONVERSION,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null
  };

  @Override
  public org.apache.avro.Conversion<?> getConversion(int field) {
    return conversions[field];
  }

  // Used by DatumReader.  Applications should not call.
  @SuppressWarnings(value="unchecked")
  public void put(int field$, java.lang.Object value$) {
    switch (field$) {
    case 0: vendor_id = (java.lang.Integer)value$; break;
    case 1: pickup_datetime = (org.joda.time.DateTime)value$; break;
    case 2: dropoff_datetime = (org.joda.time.DateTime)value$; break;
    case 3: passenger_count = (java.lang.Integer)value$; break;
    case 4: trip_distance = (java.lang.Double)value$; break;
    case 5: ratecode_id = (java.lang.Integer)value$; break;
    case 6: store_and_fwd_flag = (java.lang.CharSequence)value$; break;
    case 7: pickup_location_id = (java.lang.Integer)value$; break;
    case 8: dropoff_location_id = (java.lang.Integer)value$; break;
    case 9: payment_type = (java.lang.Integer)value$; break;
    case 10: fare_amount = (java.lang.Double)value$; break;
    case 11: extra = (java.lang.Double)value$; break;
    case 12: mta_tax = (java.lang.Double)value$; break;
    case 13: tip_amount = (java.lang.Double)value$; break;
    case 14: tolls_amount = (java.lang.Double)value$; break;
    case 15: improvement_surcharge = (java.lang.Double)value$; break;
    case 16: total_amount = (java.lang.Double)value$; break;
    case 17: trip_id = (java.lang.Long)value$; break;
    case 18: type = (java.lang.CharSequence)value$; break;
    case 19: padding = (java.lang.CharSequence)value$; break;
    default: throw new org.apache.avro.AvroRuntimeException("Bad index");
    }
  }

  /**
   * Gets the value of the 'vendor_id' field.
   * @return The value of the 'vendor_id' field.
   */
  public java.lang.Integer getVendorId() {
    return vendor_id;
  }

  /**
   * Sets the value of the 'vendor_id' field.
   * @param value the value to set.
   */
  public void setVendorId(java.lang.Integer value) {
    this.vendor_id = value;
  }

  /**
   * Gets the value of the 'pickup_datetime' field.
   * @return The value of the 'pickup_datetime' field.
   */
  public org.joda.time.DateTime getPickupDatetime() {
    return pickup_datetime;
  }

  /**
   * Sets the value of the 'pickup_datetime' field.
   * @param value the value to set.
   */
  public void setPickupDatetime(org.joda.time.DateTime value) {
    this.pickup_datetime = value;
  }

  /**
   * Gets the value of the 'dropoff_datetime' field.
   * @return The value of the 'dropoff_datetime' field.
   */
  public org.joda.time.DateTime getDropoffDatetime() {
    return dropoff_datetime;
  }

  /**
   * Sets the value of the 'dropoff_datetime' field.
   * @param value the value to set.
   */
  public void setDropoffDatetime(org.joda.time.DateTime value) {
    this.dropoff_datetime = value;
  }

  /**
   * Gets the value of the 'passenger_count' field.
   * @return The value of the 'passenger_count' field.
   */
  public java.lang.Integer getPassengerCount() {
    return passenger_count;
  }

  /**
   * Sets the value of the 'passenger_count' field.
   * @param value the value to set.
   */
  public void setPassengerCount(java.lang.Integer value) {
    this.passenger_count = value;
  }

  /**
   * Gets the value of the 'trip_distance' field.
   * @return The value of the 'trip_distance' field.
   */
  public java.lang.Double getTripDistance() {
    return trip_distance;
  }

  /**
   * Sets the value of the 'trip_distance' field.
   * @param value the value to set.
   */
  public void setTripDistance(java.lang.Double value) {
    this.trip_distance = value;
  }

  /**
   * Gets the value of the 'ratecode_id' field.
   * @return The value of the 'ratecode_id' field.
   */
  public java.lang.Integer getRatecodeId() {
    return ratecode_id;
  }

  /**
   * Sets the value of the 'ratecode_id' field.
   * @param value the value to set.
   */
  public void setRatecodeId(java.lang.Integer value) {
    this.ratecode_id = value;
  }

  /**
   * Gets the value of the 'store_and_fwd_flag' field.
   * @return The value of the 'store_and_fwd_flag' field.
   */
  public java.lang.CharSequence getStoreAndFwdFlag() {
    return store_and_fwd_flag;
  }

  /**
   * Sets the value of the 'store_and_fwd_flag' field.
   * @param value the value to set.
   */
  public void setStoreAndFwdFlag(java.lang.CharSequence value) {
    this.store_and_fwd_flag = value;
  }

  /**
   * Gets the value of the 'pickup_location_id' field.
   * @return The value of the 'pickup_location_id' field.
   */
  public java.lang.Integer getPickupLocationId() {
    return pickup_location_id;
  }

  /**
   * Sets the value of the 'pickup_location_id' field.
   * @param value the value to set.
   */
  public void setPickupLocationId(java.lang.Integer value) {
    this.pickup_location_id = value;
  }

  /**
   * Gets the value of the 'dropoff_location_id' field.
   * @return The value of the 'dropoff_location_id' field.
   */
  public java.lang.Integer getDropoffLocationId() {
    return dropoff_location_id;
  }

  /**
   * Sets the value of the 'dropoff_location_id' field.
   * @param value the value to set.
   */
  public void setDropoffLocationId(java.lang.Integer value) {
    this.dropoff_location_id = value;
  }

  /**
   * Gets the value of the 'payment_type' field.
   * @return The value of the 'payment_type' field.
   */
  public java.lang.Integer getPaymentType() {
    return payment_type;
  }

  /**
   * Sets the value of the 'payment_type' field.
   * @param value the value to set.
   */
  public void setPaymentType(java.lang.Integer value) {
    this.payment_type = value;
  }

  /**
   * Gets the value of the 'fare_amount' field.
   * @return The value of the 'fare_amount' field.
   */
  public java.lang.Double getFareAmount() {
    return fare_amount;
  }

  /**
   * Sets the value of the 'fare_amount' field.
   * @param value the value to set.
   */
  public void setFareAmount(java.lang.Double value) {
    this.fare_amount = value;
  }

  /**
   * Gets the value of the 'extra' field.
   * @return The value of the 'extra' field.
   */
  public java.lang.Double getExtra() {
    return extra;
  }

  /**
   * Sets the value of the 'extra' field.
   * @param value the value to set.
   */
  public void setExtra(java.lang.Double value) {
    this.extra = value;
  }

  /**
   * Gets the value of the 'mta_tax' field.
   * @return The value of the 'mta_tax' field.
   */
  public java.lang.Double getMtaTax() {
    return mta_tax;
  }

  /**
   * Sets the value of the 'mta_tax' field.
   * @param value the value to set.
   */
  public void setMtaTax(java.lang.Double value) {
    this.mta_tax = value;
  }

  /**
   * Gets the value of the 'tip_amount' field.
   * @return The value of the 'tip_amount' field.
   */
  public java.lang.Double getTipAmount() {
    return tip_amount;
  }

  /**
   * Sets the value of the 'tip_amount' field.
   * @param value the value to set.
   */
  public void setTipAmount(java.lang.Double value) {
    this.tip_amount = value;
  }

  /**
   * Gets the value of the 'tolls_amount' field.
   * @return The value of the 'tolls_amount' field.
   */
  public java.lang.Double getTollsAmount() {
    return tolls_amount;
  }

  /**
   * Sets the value of the 'tolls_amount' field.
   * @param value the value to set.
   */
  public void setTollsAmount(java.lang.Double value) {
    this.tolls_amount = value;
  }

  /**
   * Gets the value of the 'improvement_surcharge' field.
   * @return The value of the 'improvement_surcharge' field.
   */
  public java.lang.Double getImprovementSurcharge() {
    return improvement_surcharge;
  }

  /**
   * Sets the value of the 'improvement_surcharge' field.
   * @param value the value to set.
   */
  public void setImprovementSurcharge(java.lang.Double value) {
    this.improvement_surcharge = value;
  }

  /**
   * Gets the value of the 'total_amount' field.
   * @return The value of the 'total_amount' field.
   */
  public java.lang.Double getTotalAmount() {
    return total_amount;
  }

  /**
   * Sets the value of the 'total_amount' field.
   * @param value the value to set.
   */
  public void setTotalAmount(java.lang.Double value) {
    this.total_amount = value;
  }

  /**
   * Gets the value of the 'trip_id' field.
   * @return The value of the 'trip_id' field.
   */
  public java.lang.Long getTripId() {
    return trip_id;
  }

  /**
   * Sets the value of the 'trip_id' field.
   * @param value the value to set.
   */
  public void setTripId(java.lang.Long value) {
    this.trip_id = value;
  }

  /**
   * Gets the value of the 'type' field.
   * @return The value of the 'type' field.
   */
  public java.lang.CharSequence getType() {
    return type;
  }

  /**
   * Sets the value of the 'type' field.
   * @param value the value to set.
   */
  public void setType(java.lang.CharSequence value) {
    this.type = value;
  }

  /**
   * Gets the value of the 'padding' field.
   * @return The value of the 'padding' field.
   */
  public java.lang.CharSequence getPadding() {
    return padding;
  }

  /**
   * Sets the value of the 'padding' field.
   * @param value the value to set.
   */
  public void setPadding(java.lang.CharSequence value) {
    this.padding = value;
  }

  /**
   * Creates a new TripEvent RecordBuilder.
   * @return A new TripEvent RecordBuilder
   */
  public static TripEvent.Builder newBuilder() {
    return new TripEvent.Builder();
  }

  /**
   * Creates a new TripEvent RecordBuilder by copying an existing Builder.
   * @param other The existing builder to copy.
   * @return A new TripEvent RecordBuilder
   */
  public static TripEvent.Builder newBuilder(TripEvent.Builder other) {
    return new TripEvent.Builder(other);
  }

  /**
   * Creates a new TripEvent RecordBuilder by copying an existing TripEvent instance.
   * @param other The existing instance to copy.
   * @return A new TripEvent RecordBuilder
   */
  public static TripEvent.Builder newBuilder(TripEvent other) {
    return new TripEvent.Builder(other);
  }

  /**
   * RecordBuilder for TripEvent instances.
   */
  public static class Builder extends org.apache.avro.specific.SpecificRecordBuilderBase<TripEvent>
    implements org.apache.avro.data.RecordBuilder<TripEvent> {

    private int CpuInfo;
    private org.joda.time.DateTime pickup_datetime;
    private org.joda.time.DateTime dropoff_datetime;
    private int passenger_count;
    private double trip_distance;
    private int ratecode_id;
    private java.lang.CharSequence store_and_fwd_flag;
    private int pickup_location_id;
    private int dropoff_location_id;
    private int payment_type;
    private double fare_amount;
    private double extra;
    private double mta_tax;
    private double tip_amount;
    private double tolls_amount;
    private double improvement_surcharge;
    private double total_amount;
    private long trip_id;
    private java.lang.CharSequence type;
    private java.lang.CharSequence padding;

    /** Creates a new Builder */
    private Builder() {
      super(SCHEMA$);
    }

    /**
     * Creates a Builder by copying an existing Builder.
     * @param other The existing Builder to copy.
     */
    private Builder(TripEvent.Builder other) {
      super(other);
      if (isValidValue(fields()[0], other.CpuInfo)) {
        this.CpuInfo = data().deepCopy(fields()[0].schema(), other.CpuInfo);
        fieldSetFlags()[0] = true;
      }
      if (isValidValue(fields()[1], other.pickup_datetime)) {
        this.pickup_datetime = data().deepCopy(fields()[1].schema(), other.pickup_datetime);
        fieldSetFlags()[1] = true;
      }
      if (isValidValue(fields()[2], other.dropoff_datetime)) {
        this.dropoff_datetime = data().deepCopy(fields()[2].schema(), other.dropoff_datetime);
        fieldSetFlags()[2] = true;
      }
      if (isValidValue(fields()[3], other.passenger_count)) {
        this.passenger_count = data().deepCopy(fields()[3].schema(), other.passenger_count);
        fieldSetFlags()[3] = true;
      }
      if (isValidValue(fields()[4], other.trip_distance)) {
        this.trip_distance = data().deepCopy(fields()[4].schema(), other.trip_distance);
        fieldSetFlags()[4] = true;
      }
      if (isValidValue(fields()[5], other.ratecode_id)) {
        this.ratecode_id = data().deepCopy(fields()[5].schema(), other.ratecode_id);
        fieldSetFlags()[5] = true;
      }
      if (isValidValue(fields()[6], other.store_and_fwd_flag)) {
        this.store_and_fwd_flag = data().deepCopy(fields()[6].schema(), other.store_and_fwd_flag);
        fieldSetFlags()[6] = true;
      }
      if (isValidValue(fields()[7], other.pickup_location_id)) {
        this.pickup_location_id = data().deepCopy(fields()[7].schema(), other.pickup_location_id);
        fieldSetFlags()[7] = true;
      }
      if (isValidValue(fields()[8], other.dropoff_location_id)) {
        this.dropoff_location_id = data().deepCopy(fields()[8].schema(), other.dropoff_location_id);
        fieldSetFlags()[8] = true;
      }
      if (isValidValue(fields()[9], other.payment_type)) {
        this.payment_type = data().deepCopy(fields()[9].schema(), other.payment_type);
        fieldSetFlags()[9] = true;
      }
      if (isValidValue(fields()[10], other.fare_amount)) {
        this.fare_amount = data().deepCopy(fields()[10].schema(), other.fare_amount);
        fieldSetFlags()[10] = true;
      }
      if (isValidValue(fields()[11], other.extra)) {
        this.extra = data().deepCopy(fields()[11].schema(), other.extra);
        fieldSetFlags()[11] = true;
      }
      if (isValidValue(fields()[12], other.mta_tax)) {
        this.mta_tax = data().deepCopy(fields()[12].schema(), other.mta_tax);
        fieldSetFlags()[12] = true;
      }
      if (isValidValue(fields()[13], other.tip_amount)) {
        this.tip_amount = data().deepCopy(fields()[13].schema(), other.tip_amount);
        fieldSetFlags()[13] = true;
      }
      if (isValidValue(fields()[14], other.tolls_amount)) {
        this.tolls_amount = data().deepCopy(fields()[14].schema(), other.tolls_amount);
        fieldSetFlags()[14] = true;
      }
      if (isValidValue(fields()[15], other.improvement_surcharge)) {
        this.improvement_surcharge = data().deepCopy(fields()[15].schema(), other.improvement_surcharge);
        fieldSetFlags()[15] = true;
      }
      if (isValidValue(fields()[16], other.total_amount)) {
        this.total_amount = data().deepCopy(fields()[16].schema(), other.total_amount);
        fieldSetFlags()[16] = true;
      }
      if (isValidValue(fields()[17], other.trip_id)) {
        this.trip_id = data().deepCopy(fields()[17].schema(), other.trip_id);
        fieldSetFlags()[17] = true;
      }
      if (isValidValue(fields()[18], other.type)) {
        this.type = data().deepCopy(fields()[18].schema(), other.type);
        fieldSetFlags()[18] = true;
      }
      if (isValidValue(fields()[19], other.padding)) {
        this.padding = data().deepCopy(fields()[19].schema(), other.padding);
        fieldSetFlags()[19] = true;
      }
    }

    /**
     * Creates a Builder by copying an existing TripEvent instance
     * @param other The existing instance to copy.
     */
    private Builder(TripEvent other) {
            super(SCHEMA$);
      if (isValidValue(fields()[0], other.vendor_id)) {
        this.CpuInfo = data().deepCopy(fields()[0].schema(), other.vendor_id);
        fieldSetFlags()[0] = true;
      }
      if (isValidValue(fields()[1], other.pickup_datetime)) {
        this.pickup_datetime = data().deepCopy(fields()[1].schema(), other.pickup_datetime);
        fieldSetFlags()[1] = true;
      }
      if (isValidValue(fields()[2], other.dropoff_datetime)) {
        this.dropoff_datetime = data().deepCopy(fields()[2].schema(), other.dropoff_datetime);
        fieldSetFlags()[2] = true;
      }
      if (isValidValue(fields()[3], other.passenger_count)) {
        this.passenger_count = data().deepCopy(fields()[3].schema(), other.passenger_count);
        fieldSetFlags()[3] = true;
      }
      if (isValidValue(fields()[4], other.trip_distance)) {
        this.trip_distance = data().deepCopy(fields()[4].schema(), other.trip_distance);
        fieldSetFlags()[4] = true;
      }
      if (isValidValue(fields()[5], other.ratecode_id)) {
        this.ratecode_id = data().deepCopy(fields()[5].schema(), other.ratecode_id);
        fieldSetFlags()[5] = true;
      }
      if (isValidValue(fields()[6], other.store_and_fwd_flag)) {
        this.store_and_fwd_flag = data().deepCopy(fields()[6].schema(), other.store_and_fwd_flag);
        fieldSetFlags()[6] = true;
      }
      if (isValidValue(fields()[7], other.pickup_location_id)) {
        this.pickup_location_id = data().deepCopy(fields()[7].schema(), other.pickup_location_id);
        fieldSetFlags()[7] = true;
      }
      if (isValidValue(fields()[8], other.dropoff_location_id)) {
        this.dropoff_location_id = data().deepCopy(fields()[8].schema(), other.dropoff_location_id);
        fieldSetFlags()[8] = true;
      }
      if (isValidValue(fields()[9], other.payment_type)) {
        this.payment_type = data().deepCopy(fields()[9].schema(), other.payment_type);
        fieldSetFlags()[9] = true;
      }
      if (isValidValue(fields()[10], other.fare_amount)) {
        this.fare_amount = data().deepCopy(fields()[10].schema(), other.fare_amount);
        fieldSetFlags()[10] = true;
      }
      if (isValidValue(fields()[11], other.extra)) {
        this.extra = data().deepCopy(fields()[11].schema(), other.extra);
        fieldSetFlags()[11] = true;
      }
      if (isValidValue(fields()[12], other.mta_tax)) {
        this.mta_tax = data().deepCopy(fields()[12].schema(), other.mta_tax);
        fieldSetFlags()[12] = true;
      }
      if (isValidValue(fields()[13], other.tip_amount)) {
        this.tip_amount = data().deepCopy(fields()[13].schema(), other.tip_amount);
        fieldSetFlags()[13] = true;
      }
      if (isValidValue(fields()[14], other.tolls_amount)) {
        this.tolls_amount = data().deepCopy(fields()[14].schema(), other.tolls_amount);
        fieldSetFlags()[14] = true;
      }
      if (isValidValue(fields()[15], other.improvement_surcharge)) {
        this.improvement_surcharge = data().deepCopy(fields()[15].schema(), other.improvement_surcharge);
        fieldSetFlags()[15] = true;
      }
      if (isValidValue(fields()[16], other.total_amount)) {
        this.total_amount = data().deepCopy(fields()[16].schema(), other.total_amount);
        fieldSetFlags()[16] = true;
      }
      if (isValidValue(fields()[17], other.trip_id)) {
        this.trip_id = data().deepCopy(fields()[17].schema(), other.trip_id);
        fieldSetFlags()[17] = true;
      }
      if (isValidValue(fields()[18], other.type)) {
        this.type = data().deepCopy(fields()[18].schema(), other.type);
        fieldSetFlags()[18] = true;
      }
      if (isValidValue(fields()[19], other.padding)) {
        this.padding = data().deepCopy(fields()[19].schema(), other.padding);
        fieldSetFlags()[19] = true;
      }
    }

    /**
      * Gets the value of the 'vendor_id' field.
      * @return The value.
      */
    public java.lang.Integer getVendorId() {
      return CpuInfo;
    }

    /**
      * Sets the value of the 'vendor_id' field.
      * @param value The value of 'vendor_id'.
      * @return This builder.
      */
    public TripEvent.Builder setVendorId(int value) {
      validate(fields()[0], value);
      this.CpuInfo = value;
      fieldSetFlags()[0] = true;
      return this;
    }

    /**
      * Checks whether the 'vendor_id' field has been set.
      * @return True if the 'vendor_id' field has been set, false otherwise.
      */
    public boolean hasVendorId() {
      return fieldSetFlags()[0];
    }


    /**
      * Clears the value of the 'vendor_id' field.
      * @return This builder.
      */
    public TripEvent.Builder clearVendorId() {
      fieldSetFlags()[0] = false;
      return this;
    }

    /**
      * Gets the value of the 'pickup_datetime' field.
      * @return The value.
      */
    public org.joda.time.DateTime getPickupDatetime() {
      return pickup_datetime;
    }

    /**
      * Sets the value of the 'pickup_datetime' field.
      * @param value The value of 'pickup_datetime'.
      * @return This builder.
      */
    public TripEvent.Builder setPickupDatetime(org.joda.time.DateTime value) {
      validate(fields()[1], value);
      this.pickup_datetime = value;
      fieldSetFlags()[1] = true;
      return this;
    }

    /**
      * Checks whether the 'pickup_datetime' field has been set.
      * @return True if the 'pickup_datetime' field has been set, false otherwise.
      */
    public boolean hasPickupDatetime() {
      return fieldSetFlags()[1];
    }


    /**
      * Clears the value of the 'pickup_datetime' field.
      * @return This builder.
      */
    public TripEvent.Builder clearPickupDatetime() {
      fieldSetFlags()[1] = false;
      return this;
    }

    /**
      * Gets the value of the 'dropoff_datetime' field.
      * @return The value.
      */
    public org.joda.time.DateTime getDropoffDatetime() {
      return dropoff_datetime;
    }

    /**
      * Sets the value of the 'dropoff_datetime' field.
      * @param value The value of 'dropoff_datetime'.
      * @return This builder.
      */
    public TripEvent.Builder setDropoffDatetime(org.joda.time.DateTime value) {
      validate(fields()[2], value);
      this.dropoff_datetime = value;
      fieldSetFlags()[2] = true;
      return this;
    }

    /**
      * Checks whether the 'dropoff_datetime' field has been set.
      * @return True if the 'dropoff_datetime' field has been set, false otherwise.
      */
    public boolean hasDropoffDatetime() {
      return fieldSetFlags()[2];
    }


    /**
      * Clears the value of the 'dropoff_datetime' field.
      * @return This builder.
      */
    public TripEvent.Builder clearDropoffDatetime() {
      fieldSetFlags()[2] = false;
      return this;
    }

    /**
      * Gets the value of the 'passenger_count' field.
      * @return The value.
      */
    public java.lang.Integer getPassengerCount() {
      return passenger_count;
    }

    /**
      * Sets the value of the 'passenger_count' field.
      * @param value The value of 'passenger_count'.
      * @return This builder.
      */
    public TripEvent.Builder setPassengerCount(int value) {
      validate(fields()[3], value);
      this.passenger_count = value;
      fieldSetFlags()[3] = true;
      return this;
    }

    /**
      * Checks whether the 'passenger_count' field has been set.
      * @return True if the 'passenger_count' field has been set, false otherwise.
      */
    public boolean hasPassengerCount() {
      return fieldSetFlags()[3];
    }


    /**
      * Clears the value of the 'passenger_count' field.
      * @return This builder.
      */
    public TripEvent.Builder clearPassengerCount() {
      fieldSetFlags()[3] = false;
      return this;
    }

    /**
      * Gets the value of the 'trip_distance' field.
      * @return The value.
      */
    public java.lang.Double getTripDistance() {
      return trip_distance;
    }

    /**
      * Sets the value of the 'trip_distance' field.
      * @param value The value of 'trip_distance'.
      * @return This builder.
      */
    public TripEvent.Builder setTripDistance(double value) {
      validate(fields()[4], value);
      this.trip_distance = value;
      fieldSetFlags()[4] = true;
      return this;
    }

    /**
      * Checks whether the 'trip_distance' field has been set.
      * @return True if the 'trip_distance' field has been set, false otherwise.
      */
    public boolean hasTripDistance() {
      return fieldSetFlags()[4];
    }


    /**
      * Clears the value of the 'trip_distance' field.
      * @return This builder.
      */
    public TripEvent.Builder clearTripDistance() {
      fieldSetFlags()[4] = false;
      return this;
    }

    /**
      * Gets the value of the 'ratecode_id' field.
      * @return The value.
      */
    public java.lang.Integer getRatecodeId() {
      return ratecode_id;
    }

    /**
      * Sets the value of the 'ratecode_id' field.
      * @param value The value of 'ratecode_id'.
      * @return This builder.
      */
    public TripEvent.Builder setRatecodeId(int value) {
      validate(fields()[5], value);
      this.ratecode_id = value;
      fieldSetFlags()[5] = true;
      return this;
    }

    /**
      * Checks whether the 'ratecode_id' field has been set.
      * @return True if the 'ratecode_id' field has been set, false otherwise.
      */
    public boolean hasRatecodeId() {
      return fieldSetFlags()[5];
    }


    /**
      * Clears the value of the 'ratecode_id' field.
      * @return This builder.
      */
    public TripEvent.Builder clearRatecodeId() {
      fieldSetFlags()[5] = false;
      return this;
    }

    /**
      * Gets the value of the 'store_and_fwd_flag' field.
      * @return The value.
      */
    public java.lang.CharSequence getStoreAndFwdFlag() {
      return store_and_fwd_flag;
    }

    /**
      * Sets the value of the 'store_and_fwd_flag' field.
      * @param value The value of 'store_and_fwd_flag'.
      * @return This builder.
      */
    public TripEvent.Builder setStoreAndFwdFlag(java.lang.CharSequence value) {
      validate(fields()[6], value);
      this.store_and_fwd_flag = value;
      fieldSetFlags()[6] = true;
      return this;
    }

    /**
      * Checks whether the 'store_and_fwd_flag' field has been set.
      * @return True if the 'store_and_fwd_flag' field has been set, false otherwise.
      */
    public boolean hasStoreAndFwdFlag() {
      return fieldSetFlags()[6];
    }


    /**
      * Clears the value of the 'store_and_fwd_flag' field.
      * @return This builder.
      */
    public TripEvent.Builder clearStoreAndFwdFlag() {
      store_and_fwd_flag = null;
      fieldSetFlags()[6] = false;
      return this;
    }

    /**
      * Gets the value of the 'pickup_location_id' field.
      * @return The value.
      */
    public java.lang.Integer getPickupLocationId() {
      return pickup_location_id;
    }

    /**
      * Sets the value of the 'pickup_location_id' field.
      * @param value The value of 'pickup_location_id'.
      * @return This builder.
      */
    public TripEvent.Builder setPickupLocationId(int value) {
      validate(fields()[7], value);
      this.pickup_location_id = value;
      fieldSetFlags()[7] = true;
      return this;
    }

    /**
      * Checks whether the 'pickup_location_id' field has been set.
      * @return True if the 'pickup_location_id' field has been set, false otherwise.
      */
    public boolean hasPickupLocationId() {
      return fieldSetFlags()[7];
    }


    /**
      * Clears the value of the 'pickup_location_id' field.
      * @return This builder.
      */
    public TripEvent.Builder clearPickupLocationId() {
      fieldSetFlags()[7] = false;
      return this;
    }

    /**
      * Gets the value of the 'dropoff_location_id' field.
      * @return The value.
      */
    public java.lang.Integer getDropoffLocationId() {
      return dropoff_location_id;
    }

    /**
      * Sets the value of the 'dropoff_location_id' field.
      * @param value The value of 'dropoff_location_id'.
      * @return This builder.
      */
    public TripEvent.Builder setDropoffLocationId(int value) {
      validate(fields()[8], value);
      this.dropoff_location_id = value;
      fieldSetFlags()[8] = true;
      return this;
    }

    /**
      * Checks whether the 'dropoff_location_id' field has been set.
      * @return True if the 'dropoff_location_id' field has been set, false otherwise.
      */
    public boolean hasDropoffLocationId() {
      return fieldSetFlags()[8];
    }


    /**
      * Clears the value of the 'dropoff_location_id' field.
      * @return This builder.
      */
    public TripEvent.Builder clearDropoffLocationId() {
      fieldSetFlags()[8] = false;
      return this;
    }

    /**
      * Gets the value of the 'payment_type' field.
      * @return The value.
      */
    public java.lang.Integer getPaymentType() {
      return payment_type;
    }

    /**
      * Sets the value of the 'payment_type' field.
      * @param value The value of 'payment_type'.
      * @return This builder.
      */
    public TripEvent.Builder setPaymentType(int value) {
      validate(fields()[9], value);
      this.payment_type = value;
      fieldSetFlags()[9] = true;
      return this;
    }

    /**
      * Checks whether the 'payment_type' field has been set.
      * @return True if the 'payment_type' field has been set, false otherwise.
      */
    public boolean hasPaymentType() {
      return fieldSetFlags()[9];
    }


    /**
      * Clears the value of the 'payment_type' field.
      * @return This builder.
      */
    public TripEvent.Builder clearPaymentType() {
      fieldSetFlags()[9] = false;
      return this;
    }

    /**
      * Gets the value of the 'fare_amount' field.
      * @return The value.
      */
    public java.lang.Double getFareAmount() {
      return fare_amount;
    }

    /**
      * Sets the value of the 'fare_amount' field.
      * @param value The value of 'fare_amount'.
      * @return This builder.
      */
    public TripEvent.Builder setFareAmount(double value) {
      validate(fields()[10], value);
      this.fare_amount = value;
      fieldSetFlags()[10] = true;
      return this;
    }

    /**
      * Checks whether the 'fare_amount' field has been set.
      * @return True if the 'fare_amount' field has been set, false otherwise.
      */
    public boolean hasFareAmount() {
      return fieldSetFlags()[10];
    }


    /**
      * Clears the value of the 'fare_amount' field.
      * @return This builder.
      */
    public TripEvent.Builder clearFareAmount() {
      fieldSetFlags()[10] = false;
      return this;
    }

    /**
      * Gets the value of the 'extra' field.
      * @return The value.
      */
    public java.lang.Double getExtra() {
      return extra;
    }

    /**
      * Sets the value of the 'extra' field.
      * @param value The value of 'extra'.
      * @return This builder.
      */
    public TripEvent.Builder setExtra(double value) {
      validate(fields()[11], value);
      this.extra = value;
      fieldSetFlags()[11] = true;
      return this;
    }

    /**
      * Checks whether the 'extra' field has been set.
      * @return True if the 'extra' field has been set, false otherwise.
      */
    public boolean hasExtra() {
      return fieldSetFlags()[11];
    }


    /**
      * Clears the value of the 'extra' field.
      * @return This builder.
      */
    public TripEvent.Builder clearExtra() {
      fieldSetFlags()[11] = false;
      return this;
    }

    /**
      * Gets the value of the 'mta_tax' field.
      * @return The value.
      */
    public java.lang.Double getMtaTax() {
      return mta_tax;
    }

    /**
      * Sets the value of the 'mta_tax' field.
      * @param value The value of 'mta_tax'.
      * @return This builder.
      */
    public TripEvent.Builder setMtaTax(double value) {
      validate(fields()[12], value);
      this.mta_tax = value;
      fieldSetFlags()[12] = true;
      return this;
    }

    /**
      * Checks whether the 'mta_tax' field has been set.
      * @return True if the 'mta_tax' field has been set, false otherwise.
      */
    public boolean hasMtaTax() {
      return fieldSetFlags()[12];
    }


    /**
      * Clears the value of the 'mta_tax' field.
      * @return This builder.
      */
    public TripEvent.Builder clearMtaTax() {
      fieldSetFlags()[12] = false;
      return this;
    }

    /**
      * Gets the value of the 'tip_amount' field.
      * @return The value.
      */
    public java.lang.Double getTipAmount() {
      return tip_amount;
    }

    /**
      * Sets the value of the 'tip_amount' field.
      * @param value The value of 'tip_amount'.
      * @return This builder.
      */
    public TripEvent.Builder setTipAmount(double value) {
      validate(fields()[13], value);
      this.tip_amount = value;
      fieldSetFlags()[13] = true;
      return this;
    }

    /**
      * Checks whether the 'tip_amount' field has been set.
      * @return True if the 'tip_amount' field has been set, false otherwise.
      */
    public boolean hasTipAmount() {
      return fieldSetFlags()[13];
    }


    /**
      * Clears the value of the 'tip_amount' field.
      * @return This builder.
      */
    public TripEvent.Builder clearTipAmount() {
      fieldSetFlags()[13] = false;
      return this;
    }

    /**
      * Gets the value of the 'tolls_amount' field.
      * @return The value.
      */
    public java.lang.Double getTollsAmount() {
      return tolls_amount;
    }

    /**
      * Sets the value of the 'tolls_amount' field.
      * @param value The value of 'tolls_amount'.
      * @return This builder.
      */
    public TripEvent.Builder setTollsAmount(double value) {
      validate(fields()[14], value);
      this.tolls_amount = value;
      fieldSetFlags()[14] = true;
      return this;
    }

    /**
      * Checks whether the 'tolls_amount' field has been set.
      * @return True if the 'tolls_amount' field has been set, false otherwise.
      */
    public boolean hasTollsAmount() {
      return fieldSetFlags()[14];
    }


    /**
      * Clears the value of the 'tolls_amount' field.
      * @return This builder.
      */
    public TripEvent.Builder clearTollsAmount() {
      fieldSetFlags()[14] = false;
      return this;
    }

    /**
      * Gets the value of the 'improvement_surcharge' field.
      * @return The value.
      */
    public java.lang.Double getImprovementSurcharge() {
      return improvement_surcharge;
    }

    /**
      * Sets the value of the 'improvement_surcharge' field.
      * @param value The value of 'improvement_surcharge'.
      * @return This builder.
      */
    public TripEvent.Builder setImprovementSurcharge(double value) {
      validate(fields()[15], value);
      this.improvement_surcharge = value;
      fieldSetFlags()[15] = true;
      return this;
    }

    /**
      * Checks whether the 'improvement_surcharge' field has been set.
      * @return True if the 'improvement_surcharge' field has been set, false otherwise.
      */
    public boolean hasImprovementSurcharge() {
      return fieldSetFlags()[15];
    }


    /**
      * Clears the value of the 'improvement_surcharge' field.
      * @return This builder.
      */
    public TripEvent.Builder clearImprovementSurcharge() {
      fieldSetFlags()[15] = false;
      return this;
    }

    /**
      * Gets the value of the 'total_amount' field.
      * @return The value.
      */
    public java.lang.Double getTotalAmount() {
      return total_amount;
    }

    /**
      * Sets the value of the 'total_amount' field.
      * @param value The value of 'total_amount'.
      * @return This builder.
      */
    public TripEvent.Builder setTotalAmount(double value) {
      validate(fields()[16], value);
      this.total_amount = value;
      fieldSetFlags()[16] = true;
      return this;
    }

    /**
      * Checks whether the 'total_amount' field has been set.
      * @return True if the 'total_amount' field has been set, false otherwise.
      */
    public boolean hasTotalAmount() {
      return fieldSetFlags()[16];
    }


    /**
      * Clears the value of the 'total_amount' field.
      * @return This builder.
      */
    public TripEvent.Builder clearTotalAmount() {
      fieldSetFlags()[16] = false;
      return this;
    }

    /**
      * Gets the value of the 'trip_id' field.
      * @return The value.
      */
    public java.lang.Long getTripId() {
      return trip_id;
    }

    /**
      * Sets the value of the 'trip_id' field.
      * @param value The value of 'trip_id'.
      * @return This builder.
      */
    public TripEvent.Builder setTripId(long value) {
      validate(fields()[17], value);
      this.trip_id = value;
      fieldSetFlags()[17] = true;
      return this;
    }

    /**
      * Checks whether the 'trip_id' field has been set.
      * @return True if the 'trip_id' field has been set, false otherwise.
      */
    public boolean hasTripId() {
      return fieldSetFlags()[17];
    }


    /**
      * Clears the value of the 'trip_id' field.
      * @return This builder.
      */
    public TripEvent.Builder clearTripId() {
      fieldSetFlags()[17] = false;
      return this;
    }

    /**
      * Gets the value of the 'type' field.
      * @return The value.
      */
    public java.lang.CharSequence getType() {
      return type;
    }

    /**
      * Sets the value of the 'type' field.
      * @param value The value of 'type'.
      * @return This builder.
      */
    public TripEvent.Builder setType(java.lang.CharSequence value) {
      validate(fields()[18], value);
      this.type = value;
      fieldSetFlags()[18] = true;
      return this;
    }

    /**
      * Checks whether the 'type' field has been set.
      * @return True if the 'type' field has been set, false otherwise.
      */
    public boolean hasType() {
      return fieldSetFlags()[18];
    }


    /**
      * Clears the value of the 'type' field.
      * @return This builder.
      */
    public TripEvent.Builder clearType() {
      type = null;
      fieldSetFlags()[18] = false;
      return this;
    }

    /**
      * Gets the value of the 'padding' field.
      * @return The value.
      */
    public java.lang.CharSequence getPadding() {
      return padding;
    }

    /**
      * Sets the value of the 'padding' field.
      * @param value The value of 'padding'.
      * @return This builder.
      */
    public TripEvent.Builder setPadding(java.lang.CharSequence value) {
      validate(fields()[19], value);
      this.padding = value;
      fieldSetFlags()[19] = true;
      return this;
    }

    /**
      * Checks whether the 'padding' field has been set.
      * @return True if the 'padding' field has been set, false otherwise.
      */
    public boolean hasPadding() {
      return fieldSetFlags()[19];
    }


    /**
      * Clears the value of the 'padding' field.
      * @return This builder.
      */
    public TripEvent.Builder clearPadding() {
      padding = null;
      fieldSetFlags()[19] = false;
      return this;
    }

    @Override
    @SuppressWarnings("unchecked")
    public TripEvent build() {
      try {
        TripEvent record = new TripEvent();
        record.vendor_id = fieldSetFlags()[0] ? this.CpuInfo : (java.lang.Integer) defaultValue(fields()[0], record.getConversion(0));
        record.pickup_datetime = fieldSetFlags()[1] ? this.pickup_datetime : (org.joda.time.DateTime) defaultValue(fields()[1], record.getConversion(1));
        record.dropoff_datetime = fieldSetFlags()[2] ? this.dropoff_datetime : (org.joda.time.DateTime) defaultValue(fields()[2], record.getConversion(2));
        record.passenger_count = fieldSetFlags()[3] ? this.passenger_count : (java.lang.Integer) defaultValue(fields()[3], record.getConversion(3));
        record.trip_distance = fieldSetFlags()[4] ? this.trip_distance : (java.lang.Double) defaultValue(fields()[4], record.getConversion(4));
        record.ratecode_id = fieldSetFlags()[5] ? this.ratecode_id : (java.lang.Integer) defaultValue(fields()[5], record.getConversion(5));
        record.store_and_fwd_flag = fieldSetFlags()[6] ? this.store_and_fwd_flag : (java.lang.CharSequence) defaultValue(fields()[6], record.getConversion(6));
        record.pickup_location_id = fieldSetFlags()[7] ? this.pickup_location_id : (java.lang.Integer) defaultValue(fields()[7], record.getConversion(7));
        record.dropoff_location_id = fieldSetFlags()[8] ? this.dropoff_location_id : (java.lang.Integer) defaultValue(fields()[8], record.getConversion(8));
        record.payment_type = fieldSetFlags()[9] ? this.payment_type : (java.lang.Integer) defaultValue(fields()[9], record.getConversion(9));
        record.fare_amount = fieldSetFlags()[10] ? this.fare_amount : (java.lang.Double) defaultValue(fields()[10], record.getConversion(10));
        record.extra = fieldSetFlags()[11] ? this.extra : (java.lang.Double) defaultValue(fields()[11], record.getConversion(11));
        record.mta_tax = fieldSetFlags()[12] ? this.mta_tax : (java.lang.Double) defaultValue(fields()[12], record.getConversion(12));
        record.tip_amount = fieldSetFlags()[13] ? this.tip_amount : (java.lang.Double) defaultValue(fields()[13], record.getConversion(13));
        record.tolls_amount = fieldSetFlags()[14] ? this.tolls_amount : (java.lang.Double) defaultValue(fields()[14], record.getConversion(14));
        record.improvement_surcharge = fieldSetFlags()[15] ? this.improvement_surcharge : (java.lang.Double) defaultValue(fields()[15], record.getConversion(15));
        record.total_amount = fieldSetFlags()[16] ? this.total_amount : (java.lang.Double) defaultValue(fields()[16], record.getConversion(16));
        record.trip_id = fieldSetFlags()[17] ? this.trip_id : (java.lang.Long) defaultValue(fields()[17], record.getConversion(17));
        record.type = fieldSetFlags()[18] ? this.type : (java.lang.CharSequence) defaultValue(fields()[18], record.getConversion(18));
        record.padding = fieldSetFlags()[19] ? this.padding : (java.lang.CharSequence) defaultValue(fields()[19], record.getConversion(19));
        return record;
      } catch (java.lang.Exception e) {
        throw new org.apache.avro.AvroRuntimeException(e);
      }
    }
  }

  @SuppressWarnings("unchecked")
  private static final org.apache.avro.io.DatumWriter<TripEvent>
    WRITER$ = (org.apache.avro.io.DatumWriter<TripEvent>)MODEL$.createDatumWriter(SCHEMA$);

  @Override public void writeExternal(java.io.ObjectOutput out)
    throws java.io.IOException {
    WRITER$.write(this, SpecificData.getEncoder(out));
  }

  @SuppressWarnings("unchecked")
  private static final org.apache.avro.io.DatumReader<TripEvent>
    READER$ = (org.apache.avro.io.DatumReader<TripEvent>)MODEL$.createDatumReader(SCHEMA$);

  @Override public void readExternal(java.io.ObjectInput in)
    throws java.io.IOException {
    READER$.read(this, SpecificData.getDecoder(in));
  }

}
